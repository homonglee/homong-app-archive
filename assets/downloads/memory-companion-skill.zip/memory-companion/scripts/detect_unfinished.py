#!/usr/bin/env python
"""Detect open commitments that need follow-up from JSONL records."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any


def parse_date(value: Any) -> date | None:
    if not value:
        return None
    text = str(value).strip()
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return None


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"line {line_number}: invalid JSON: {exc.msg}") from exc
            if not isinstance(value, dict):
                raise ValueError(f"line {line_number}: record must be a JSON object")
            records.append(value)
    return records


def detect(
    records: list[dict[str, Any]],
    today: date,
    follow_up_days: int,
    cooldown_days: int,
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    undated_cutoff = today - timedelta(days=follow_up_days)
    cooldown_cutoff = today - timedelta(days=cooldown_days)

    for record in records:
        if record.get("status") != "open":
            continue
        if record.get("commitment_level") not in {"explicit", "implied"}:
            continue
        if record.get("completion_evidence"):
            continue
        if not record.get("follow_up_required", True):
            continue

        last_follow_up = parse_date(record.get("last_followed_up_at"))
        if last_follow_up and last_follow_up > cooldown_cutoff:
            continue

        due = parse_date(record.get("due_date"))
        captured = parse_date(record.get("captured_at"))
        reason: str | None = None
        days: int | None = None

        if due and due <= today:
            days = (today - due).days
            reason = "due_today" if days == 0 else "overdue"
        elif due is None and captured and captured <= undated_cutoff:
            days = (today - captured).days
            reason = "undated_stalled"

        if reason:
            candidates.append(
                {
                    "id": record.get("id"),
                    "action": record.get("action") or record.get("original_text"),
                    "people": record.get("people") or [],
                    "project": record.get("project"),
                    "due_date": record.get("due_date"),
                    "reason": reason,
                    "days": days,
                    "source_ref": record.get("source_ref"),
                }
            )

    reason_order = {"overdue": 0, "due_today": 1, "undated_stalled": 2}
    candidates.sort(key=lambda item: (reason_order[item["reason"]], -(item["days"] or 0), str(item["id"])))
    return candidates


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jsonl", type=Path, help="Path to UTF-8 JSONL memory records")
    parser.add_argument("--today", type=date.fromisoformat, default=date.today())
    parser.add_argument("--follow-up-days", type=int, default=3)
    parser.add_argument("--cooldown-days", type=int, default=2)
    args = parser.parse_args()

    if args.follow_up_days < 0 or args.cooldown_days < 0:
        parser.error("day intervals must be zero or greater")

    try:
        records = load_jsonl(args.jsonl)
        candidates = detect(records, args.today, args.follow_up_days, args.cooldown_days)
    except (OSError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2

    print(
        json.dumps(
            {"ok": True, "today": args.today.isoformat(), "count": len(candidates), "candidates": candidates},
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
