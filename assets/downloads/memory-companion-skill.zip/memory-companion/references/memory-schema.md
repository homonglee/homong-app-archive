# Canonical Memory Record Schema

Use these field names across Markdown, JSONL, and database adapters.

## Required fields

| Field | Type | Meaning |
|---|---|---|
| `id` | string | Stable unique ID, such as `mem_20260815_001` |
| `captured_at` | ISO datetime | Capture time with timezone |
| `original_text` | string | Verbatim user wording |
| `memory_type` | enum | `commitment`, `task`, `decision`, `idea`, `fact` |
| `action` | string/null | Normalized action without invented detail |
| `commitment_level` | enum | `explicit`, `implied`, `none` |
| `status` | enum | `open`, `completed`, `cancelled` |
| `priority` | enum | `low`, `normal`, `high`, `urgent` |
| `follow_up_required` | boolean | Whether status should be checked |
| `confidence` | number | Classification confidence from 0 to 1 |

## Context fields

| Field | Type | Meaning |
|---|---|---|
| `people` | string[] | Named people or roles |
| `project` | string/null | Project or workstream |
| `date_expression` | string/null | Original relative or natural-language date |
| `due_date` | ISO date/null | Resolved due date |
| `date_timezone` | string/null | Timezone used for resolution |
| `source_type` | string | `conversation`, `plaud`, `obsidian`, etc. |
| `source_ref` | string/null | Message ID, note path, recording ID, or URL |
| `context_excerpt` | string/null | Minimal surrounding context |
| `unresolved_fields` | string[] | Fields requiring clarification |

## State and evidence fields

| Field | Type | Meaning |
|---|---|---|
| `completed_at` | ISO datetime/null | Completion time |
| `completion_evidence` | string/null | User statement or trusted artifact |
| `cancelled_at` | ISO datetime/null | Cancellation time |
| `last_confirmed_at` | ISO datetime/null | Last status confirmation |
| `last_followed_up_at` | ISO datetime/null | Last reminder/check |
| `created_by` | string | Capturing agent or integration |
| `updated_at` | ISO datetime | Last mutation time |

## Invariants

1. `original_text` is immutable unless the user explicitly requests source deletion.
2. `completed_at` and `completion_evidence` are required when status is `completed`.
3. `cancelled_at` is required when status is `cancelled`.
4. `due_date` must not be fabricated. Keep it null when unresolved.
5. Every mutation updates `updated_at`.
6. Every external retrieval answer includes `id` or `source_ref`.

## Example JSONL record

```json
{"id":"mem_20260812_001","captured_at":"2026-08-12T09:00:00+09:00","original_text":"다음 주에 김대표에게 견적 보내야 해.","memory_type":"commitment","people":["김대표"],"project":"견적 업무","action":"김대표에게 견적 보내기","date_expression":"다음 주","due_date":"2026-08-19","date_timezone":"Asia/Seoul","commitment_level":"explicit","status":"open","priority":"normal","follow_up_required":true,"confidence":0.94,"source_type":"conversation","source_ref":"telegram:message:123","context_excerpt":null,"unresolved_fields":[],"completed_at":null,"completion_evidence":null,"cancelled_at":null,"last_confirmed_at":null,"last_followed_up_at":null,"created_by":"memory-companion","updated_at":"2026-08-12T09:00:00+09:00"}
```
