---
id: "{{id}}"
captured_at: "{{captured_at}}"
memory_type: "{{memory_type}}"
people: {{people_json}}
project: {{project_yaml}}
action: {{action_yaml}}
date_expression: {{date_expression_yaml}}
due_date: {{due_date_yaml}}
date_timezone: {{date_timezone_yaml}}
commitment_level: "{{commitment_level}}"
status: "{{status}}"
priority: "{{priority}}"
follow_up_required: {{follow_up_required}}
confidence: {{confidence}}
source_type: "{{source_type}}"
source_ref: {{source_ref_yaml}}
completed_at: null
completion_evidence: null
cancelled_at: null
last_confirmed_at: null
last_followed_up_at: null
created_by: "memory-companion"
updated_at: "{{updated_at}}"
---

# {{action_or_summary}}

## 원문

> {{original_text}}

## 분류

- **사람:** {{people_display}}
- **프로젝트:** {{project_display}}
- **행동:** {{action_display}}
- **날짜 표현:** {{date_expression_display}}
- **마감일:** {{due_date_display}}
- **상태:** {{status}}
- **중요도:** {{priority}}
- **후속 확인:** {{follow_up_required}}
- **신뢰도:** {{confidence}}

## 출처

- **유형:** {{source_type}}
- **참조:** {{source_ref_display}}

## 상태 기록

- {{captured_at}} — 기억 생성
